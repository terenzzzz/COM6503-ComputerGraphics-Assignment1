public class NameNode extends SGNode {
  /**
   * These codes are the same as the lab material
   */
  public NameNode(String name) {
    super(name);
  }
  
}